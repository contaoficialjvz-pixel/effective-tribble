import discord
from discord.ext import commands
import asyncio
import json
import os
import random
from datetime import datetime

# ------------------------------------------------------------------
# CONFIGURAÇÕES E INTENTS
# ------------------------------------------------------------------
intents = discord.Intents.default()
intents.message_content = True 
intents.guilds = True
intents.messages = True

ARQUIVO_VENDAS = "vendas_registradas.json"

def salvar_venda(cliente_nome, cliente_id, link_arquivo, key_cheat):
    dados = []
    if os.path.exists(ARQUIVO_VENDAS):
        try:
            with open(ARQUIVO_VENDAS, "r", encoding="utf-8") as f:
                dados = json.load(f)
        except:
            dados = []

    registro = {
        "cliente": cliente_nome,
        "id": cliente_id,
        "link_arquivo": link_arquivo,
        "key_cheat": key_cheat,
        "data": datetime.now().strftime("%d/%m/%Y - %H:%M:%S")
    }
    dados.append(registro)

    with open(ARQUIVO_VENDAS, "w", encoding="utf-8") as f:
        json.dump(dados, f, indent=4, ensure_ascii=False)


# ------------------------------------------------------------------
# 1. BOTÕES DENTRO DO CARRINHO (RESPOSTAS INSTANTÂNEAS)
# ------------------------------------------------------------------
class BotoesCarrinhoView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(
        label="Escolher o Pagamento", 
        style=discord.ButtonStyle.success, 
        emoji="✅", 
        custom_id="btn_pagamento_v111"
    )
    async def btn_pagamento(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            "💳 **Chave PIX / Opções de Pagamento:**\n"
            "Chave PIX (CPF): `127.356.937-75`\n\n"
            "⚠️ **sem o comprovante você não receberá o produto importante envie o comprovante agora mesmo** ⚠️\n\n"
            "Após realizar o pagamento, envie a foto do comprovante diretamente aqui neste canal!"
        )

    @discord.ui.button(
        label="Enviar Comprovante", 
        style=discord.ButtonStyle.primary, 
        emoji="📷", 
        custom_id="btn_enviar_comprovante_v111"
    )
    async def btn_enviar_comprovante(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message(
            f"⚠️ **sem o comprovante você não receberá o produto importante envie o comprovante agora mesmo** ⚠️\n\n"
            f"📱 {interaction.user.mention}, toque no ícone de **`+`** (anexo) ao lado da barra de texto, escolha a foto do comprovante na sua galeria e envie aqui no chat!",
            ephemeral=True
        )

    @discord.ui.button(
        label="Cancelar Compra", 
        style=discord.ButtonStyle.danger, 
        emoji="✖️", 
        custom_id="btn_cancelar_v111"
    )
    async def btn_cancelar(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("❌ **Compra cancelada.** Fechando o carrinho...")
        await asyncio.sleep(1)
        try:
            await interaction.channel.delete(reason="Carrinho cancelado pelo cliente")
        except Exception as e:
            print(f"Erro ao apagar canal: {e}")


# ------------------------------------------------------------------
# 2. DROPDOWN DE PRODUTOS
# ------------------------------------------------------------------
class DropdownProdutos(discord.ui.Select):
    def __init__(self):
        options = [
            discord.SelectOption(label="ANDROID INJECTOR 1 DIA", description="💸 Valor: 4,99 | 📦 Estoque: ilimitado", emoji="🛒"),
            discord.SelectOption(label="ANDROID INJECTOR 3 DIAS", description="💸 Valor: 7,99 | 📦 Estoque: ilimitado", emoji="🛒"),
            discord.SelectOption(label="ANDROID INJECTOR 10 DIAS", description="💸 Valor: 19,99 | 📦 Estoque: ilimitado", emoji="🛒"),
            discord.SelectOption(label="ANDROID INJECTOR 30 DIAS", description="💸 Valor: 29,99 | 📦 Estoque: ilimitado", emoji="🛒"),
        ]
        super().__init__(
            placeholder="Selecione um Produto abaixo",
            min_values=1,
            max_values=1,
            options=options,
            custom_id="select_loja_v111"
        )

    async def callback(self, interaction: discord.Interaction):
        await interaction.response.defer(ephemeral=True)
        
        precos = {
            "ANDROID INJECTOR 1 DIA": "4,99",
            "ANDROID INJECTOR 3 DIAS": "7,99",
            "ANDROID INJECTOR 10 DIAS": "19,99",
            "ANDROID INJECTOR 30 DIAS": "29,99"
        }
        escolha = self.values[0]
        valor = precos.get(escolha, "4,99")
        guild = interaction.guild
        user = interaction.user

        sufixo = random.randint(1000, 9999)
        nome_usuario = "".join(c for c in user.name.lower() if c.isalnum())
        nome_carrinho = f"carrinho-{nome_usuario}-{sufixo}"

        overwrites_carrinho = {
            guild.default_role: discord.PermissionOverwrite(read_messages=False, view_channel=False),
            user: discord.PermissionOverwrite(read_messages=True, send_messages=True, view_channel=True),
            guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True, view_channel=True)
        }

        canal_carrinho = await guild.create_text_channel(name=nome_carrinho, overwrites=overwrites_carrinho)

        embed_carrinho = discord.Embed(
            title="🛒 CARRINHO DE COMPRAS",
            description=(
                f"Olá {user.mention}, seu carrinho para a Key foi criado!\n\n"
                f"📦 **Produto:** {escolha}\n"
                f"💸 **Valor:** R$ {valor}\n\n"
                f"⚠️ **sem o comprovante você não receberá o produto importante envie o comprovante agora mesmo** ⚠️\n\n"
                f"1️⃣ Clique em **Escolher o Pagamento** para ver a chave PIX.\n"
                f"2️⃣ Faça a transferência e envie a foto do comprovante aqui!"
            ),
            color=0x00A2FF
        )
        await canal_carrinho.send(content=f"{user.mention}", embed=embed_carrinho, view=BotoesCarrinhoView())
        await interaction.followup.send(f"✅ Seu carrinho foi criado em {canal_carrinho.mention}!", ephemeral=True)


class LojaView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        self.add_item(DropdownProdutos())


def criar_embed_loja():
    embed = discord.Embed(
        title="FLUTUANTE ANDROID INJECTOR",
        description=(
            "📦 **Produto — FLUTUANTE ANDROID INJECTOR**\n\n"
            "📱 **Compatível com todas as versões Android**\n"
            "📁 **Arquivo acompanha tutorial completo de instalação**\n"
            "⚡ **Instalação rápida — sem necessidade de PC ou notebook**\n"
            "🔒 **Sem root, sem formatação — 100% seguro para o seu dispositivo**"
        ),
        color=0x00A2FF
    )
    embed.set_image(url="https://raw.githubusercontent.com/contaoficialjvz-pixel/effective-tribble/refs/heads/main/Novo%20projeto%2049%20%5B0ACE50B%5D.png")
    return embed


# ------------------------------------------------------------------
# 3. CLASSE DO BOT E EVENTOS
# ------------------------------------------------------------------
class BotEspecial(commands.Bot):
    def __init__(self):
        super().__init__(command_prefix="!", intents=intents)

    async def setup_hook(self):
        self.add_view(LojaView())
        self.add_view(BotoesCarrinhoView())


bot = BotEspecial()

@bot.event
async def on_ready():
    try:
        synced = await bot.tree.sync()
        print(f"✅ {len(synced)} Comandos Sincronizados!")
    except Exception as e:
        print(f"Erro na sincronização: {e}")
    print(f"✅ BOT {bot.user} ONLINE E PRONTO!")


@bot.event
async def on_message(message: discord.Message):
    if message.author.bot:
        return

    if "carrinho" in message.channel.name.lower():
        if message.attachments:
            for attachment in message.attachments:
                is_image = attachment.content_type and attachment.content_type.startswith("image/")
                is_image_ext = attachment.filename.lower().endswith(('.png', '.jpg', '.jpeg', '.webp'))

                if is_image or is_image_ext:
                    canal_registres = discord.utils.find(lambda c: c.name.lower() == "registres", message.guild.text_channels)
                    if not canal_registres:
                        overwrites_registres = {
                            message.guild.default_role: discord.PermissionOverwrite(read_messages=False, view_channel=False),
                            message.guild.owner: discord.PermissionOverwrite(read_messages=True, send_messages=True, view_channel=True),
                            message.guild.me: discord.PermissionOverwrite(read_messages=True, send_messages=True, manage_channels=True, view_channel=True)
                        }
                        canal_registres = await message.guild.create_text_channel(name="registres", overwrites=overwrites_registres)

                    nome_canal_texto = f"#{message.channel.name}"

                    embed_comp = discord.Embed(
                        title="📩 NOVO COMPROVANTE ENVIADO!",
                        description=f"O cliente {message.author.mention} enviou um comprovante no carrinho **`{nome_canal_texto}`**.",
                        color=0x00FF7F,
                        timestamp=datetime.now()
                    )
                    embed_comp.add_field(name="👤 Cliente:", value=f"{message.author.mention} (`{message.author.name}` - `{message.author.id}`)", inline=False)
                    embed_comp.add_field(name="📍 Canal:", value=f"`{nome_canal_texto}`", inline=False)
                    embed_comp.set_image(url=attachment.url)
                    
                    await canal_registres.send(embed=embed_comp)
                    await message.channel.send(f"✅ {message.author.mention}, comprovante recebido! Aguarde a liberação da Key e do Arquivo.")
                    break

    await bot.process_commands(message)


# ------------------------------------------------------------------
# 4. COMANDOS DO BOT
# ------------------------------------------------------------------

@bot.command(name="injector")
async def injector_prefix(ctx):
    await ctx.send(embed=criar_embed_loja(), view=LojaView())


@bot.tree.command(name="injector", description="Exibe o painel de compras do Injector Android")
async def injector_slash(interaction: discord.Interaction):
    await interaction.response.defer()
    await interaction.followup.send(embed=criar_embed_loja(), view=LojaView())


@bot.tree.command(name="aprovar", description="Aprova a compra, envia o link e a key no PV do cliente e registra a venda")
async def aprovar_slash(interaction: discord.Interaction, membro: discord.Member, link_arquivo: str, key_cheat: str):
    await interaction.response.defer(thinking=True)

    if not interaction.user.guild_permissions.administrator:
        await interaction.followup.send("❌ Apenas administradores podem executar este comando!", ephemeral=True)
        return

    cargo_links = discord.utils.get(interaction.guild.roles, name="LINKS")
    if not cargo_links:
        await interaction.followup.send("❌ O cargo 'LINKS' não foi encontrado no servidor!", ephemeral=True)
        return

    await membro.add_roles(cargo_links)
    salvar_venda(str(membro), membro.id, link_arquivo, key_cheat)

    try:
        embed_pv = discord.Embed(
            title="🎉 SEU PEDIDO FOI APROVADO!",
            description=(
                f"Olá {membro.mention}, o seu pagamento foi confirmado com sucesso!\n\n"
                f"🔑 **Sua Key do Injector:** `{key_cheat}`\n"
                f"📥 **Link do Arquivo / Injector:** {link_arquivo}\n\n"
                f"✅ O seu cargo **LINKS** foi liberado no servidor."
            ),
            color=0x00FF7F,
            timestamp=datetime.now()
        )
        await membro.send(embed=embed_pv)
        msg_dm = "✅ Link do arquivo e Key enviados com sucesso no PV (DM) do cliente!"
    except Exception:
        msg_dm = "⚠️ A DM/PV do cliente está fechada! Informe o link e a Key a ele manualmente."

    canal_registres = discord.utils.find(lambda c: c.name.lower() == "registres", interaction.guild.text_channels)
    if canal_registres:
        embed_log = discord.Embed(
            title="✅ COMPRA APROVADA E REGISTRADA",
            color=0x00FF7F,
            timestamp=datetime.now()
        )
        embed_log.add_field(name="👤 Cliente:", value=f"{membro.mention} (`{membro.name}`)", inline=False)
        embed_log.add_field(name="🆔 ID:", value=f"`{membro.id}`", inline=False)
        embed_log.add_field(name="📥 Link do Arquivo:", value=f"{link_arquivo}", inline=False)
        embed_log.add_field(name="🔑 Key:", value=f"`{key_cheat}`", inline=False)
        embed_log.add_field(name="👑 Aprovado por:", value=f"{interaction.user.mention}", inline=False)
        await canal_registres.send(embed=embed_log)

    await interaction.followup.send(
        f"✅ **Pagamento Aprovado!**\n"
        f"👤 Cliente: {membro.mention}\n"
        f"🎖️ Cargo **LINKS** concedido.\n"
        f"📩 {msg_dm}"
    )

# Cole o seu NOVO TOKEN gerado no Discord Developer Portal abaixo:
bot.run("MTU1MTYxMzcyMDI3MzM1NDc2Mg.GH0aWI.HVGarDFhAR5ng10oCmvju0KLRNJkLc4xTfHkjw")
